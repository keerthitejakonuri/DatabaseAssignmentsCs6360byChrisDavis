Written in Java


Compiling Instructions:



Code compilation:

	javac MyDatabase.java




Running the code:

	java MyDatabase
	
	

Note:The input import file must be in the same location as MyDatabase.java file or path should be specified from MyDatabase.java location to the input import file.

While entering the Drug_ID please check the format.It should be (char)(char)-(digit)(digit)(digit).
